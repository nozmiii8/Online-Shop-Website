---
title: "Location"
date: 2024-05-08
hidemeta: true
description: "Professor Dr von Igelfeld's mailing and office addresses at the Institute of Romance Philology."

---

---

#### Mailing address

Professor Dr von Igelfeld  
Institute of Romance Philology  
University of Regensburg  
Regensburg, Germany

---

#### Office address

Room 133  
Institute of Romance Philology  
University of Regensburg

---

#### Office location

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d10470.896334563153!2d12.085487114429176!3d48.99680799095555!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x479fc1126394f30f%3A0xb4c5000594ee5334!2sUniversity%20of%20Regensburg!5e0!3m2!1sen!2sus!4v1714871932562!5m2!1sen!2sus" 
width="700" height="500" style="border:0;" allowfullscreen="" loading="lazy"></iframe>


