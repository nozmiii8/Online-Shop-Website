---
title: "Papers"
description: "Preprints and articles by Professor Dr von Igelfeld."
---